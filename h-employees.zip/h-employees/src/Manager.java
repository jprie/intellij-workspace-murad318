public class Manager extends Employee {

    protected Manager(String name) {
        super(name);
    }

    @Override
    public int getSalary() {
        return 5000;
    }
}
