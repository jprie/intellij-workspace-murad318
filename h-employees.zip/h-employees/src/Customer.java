public class Customer implements Greetable {

    private String name;

    public Customer(String name) {
        this.name = name;
    }

    @Override
    public void greet(String name) {
        System.out.println("Merry Christmas dear Customer: " + name);
    }
}
