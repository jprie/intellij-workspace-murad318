public abstract class Employee {

    private String name;

    protected Employee(String name) {
        this.name = name;
    }

    public abstract int getSalary();
}
