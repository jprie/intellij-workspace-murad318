public interface Greetable {

    void greet(String name);
}
